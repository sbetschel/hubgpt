Documents are in docs folder. Process each one for each step
read first file perform all steps for that file then move to next file until all files are processed. Do not return to user until all files are processed.

Create a md file for each document.

step 1:

prompt: looking at the document create a markdown file with just the outline for all essential elements. This just will be a skeleton outline only

step 2:

prompt again looking at the document write summary of each section and other relevant high level details in the markdwon file

step 3:
prompt: create all minute details and tables and other relevant details in the markdown file